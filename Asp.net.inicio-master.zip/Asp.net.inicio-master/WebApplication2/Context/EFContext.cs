﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class EFContext : DbContext
    {
        public EFContext() : base("Asp_Net_MVC_CS") { } 
        public DbSet<Categoria> Categorias { get; set; } // criar uma tabela com base na Categoria
        public DbSet<Fabricante> Fabricantes { get; set; }

    }
}